APOE HMM Project Files

Contents:
- APOE_isoforms.fasta: Protein sequences of human APOE2, APOE3, APOE4
- Mammal_APOE_candidates.fasta: APOE-like protein sequences from 10 mammals
- run_hmmer.sh: SLURM script to build and search a Hidden Markov Model on Ocelote

Instructions:
1. Log into Ocelote
2. Run: wget https://your.link/APOE_HMM_Project.tar.gz
3. Extract: tar xvf APOE_HMM_Project.tar.gz
4. Load HMMER: module load hmmer/3.3.2
5. Submit job: sbatch run_hmmer.sh

Modify 'run_hmmer.sh' to set your SLURM --account name.
